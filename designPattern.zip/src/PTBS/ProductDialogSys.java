package PTBS;

import javax.swing.JDialog;
// displays product dialog box- chooosing product and their type.
public class ProductDialogSys extends JDialog{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Product ShowDlg(ClassProductList productList) {
		// TODO Auto-generated method stub
		return null;
	}
	

	
}