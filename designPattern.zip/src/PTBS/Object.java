package PTBS;
public class Object {

}
