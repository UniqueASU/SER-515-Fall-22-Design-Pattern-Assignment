package PTBS;

import java.util.*;
// main function is implemented here
@SuppressWarnings("unused")
public class App {

	public static Facade facade = new Facade();

	public App() {

	};

	public static void main(String[] args) {

		UserInfoItem user = new UserInfoItem();

		boolean f = false;
		f = Facade.Login(user);
		
		//on click of exit button
		if (f)
			System.exit(0);

	}
}
