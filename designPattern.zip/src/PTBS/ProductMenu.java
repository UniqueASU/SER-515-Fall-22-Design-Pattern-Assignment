package PTBS;

import java.awt.event.*;



import java.util.Iterator;
import javax.swing.*;

import java.awt.*;


//This function maintains the product menu
 abstract public class  ProductMenu extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@SuppressWarnings("unused")
	private Person person;
	
	public Product Tproduct;
	
	
	public boolean quit = true;
	JRadioButton tradingRadio = new JRadioButton();
	
	JButton tradingAddButton = new JButton();
	JButton tradingViewButton = new JButton();
	
	JRadioButton Radiobutton = new JRadioButton();
	
	JLabel tradingContentLable = new JLabel();
	
	JButton buttonChangeProduct = new JButton();

	JComboBox optioninsideCombo = new JComboBox();
	
	
	JButton insertViewButton = new JButton();
	JButton insertAddButton = new JButton();
	
	
	
	
	JButton BLogout = new JButton();


	public ProductMenu() {

		try {

			jbInit();
		} catch (Exception ee) {

			ee.printStackTrace();
		}
		setModal(true);
		setSize(500, 290);
	}
	
	private void jbInit() throws Exception {

		buttonChangeProduct.setText("ChangeProduct");
		buttonChangeProduct.setBounds(new Rectangle(111, 212, 76, 40));
		
		buttonChangeProduct.addActionListener(new java.awt.event.ActionListener() {

			public void actionPerformed(ActionEvent e) {

				buttonChangeProductActionPerformed(e);
			}
		});
		
		
		
		this.getContentPane().setLayout(null);
		this.setTitle("");
		
		BLogout.setBounds(new Rectangle( 272, 219 , 77, 52) );
		BLogout.setText("Logout");
		
		BLogout.addActionListener(new java.awt.event.ActionListener() {

			public void actionPerformed(ActionEvent e) {

				buttonLogoutActionPerformed(e);
			}
		});
		this.getContentPane().add(buttonChangeProduct, null);
		this.getContentPane().add(BLogout, null);
	}
	
	JComboBox<Trading> tradingx = new JComboBox<Trading>();
	
	void render() {
		
		tradingx.removeAllItems();
		Iterator<Trading> mv = Tproduct.tradeList.iterator();
		while(mv.hasNext()) {
			tradingx.addItem(mv.next());
			
		}
	}
	
	void TradingAddButtonActionPerformed(  ActionEvent t) {
		App.facade.addTrading(Tproduct);
		
		render();
	}
	
	
	
	void TradingViewButtonActionPerformed( ActionEvent t) {
		
		Trading trade = (Trading) tradingx.getSelectedItem();
		
		App.facade.viewTrading(trade);
	};
	
	void buttonChangeProductActionPerformed(ActionEvent t){
		setVisible(false);
		quit = false;
	}
	
	void buttonLogoutActionPerformed(ActionEvent t) {
		setVisible(false);
		quit = true;
	}
	
	boolean ifLogout() {
		return quit;
	}
	public abstract void showMenu(Product product);

	public abstract void showAddButton();

	public abstract void showViewButton();

	public abstract void showRadioButton();

	public abstract void showLabels();

	public abstract void showComboxes();
	
	

}
