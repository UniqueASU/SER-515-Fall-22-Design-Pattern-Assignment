package PTBS;

//offering menu is being wrapped by the facade.
public class OfferingMenu {

	public void ShowMenu(Offering offer) {
		// Show offering menu dialog
		// TODO Auto-generated method stub
		
	}

}
