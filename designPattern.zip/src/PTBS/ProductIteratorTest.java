package PTBS;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ProductIteratorTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
