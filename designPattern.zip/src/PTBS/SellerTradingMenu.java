package PTBS;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;


import java.awt.event.ActionEvent;
import java.awt.Rectangle;

import java.util.Date;



//implements Factory method design pattern by instantiating 

@SuppressWarnings("unused")
public class SellerTradingMenu extends TradingMenu {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private boolean boolSubmit = false;
	private Offering offer;
	private Trading strade;

	JLabel lTradingName = new JLabel();
	JLabel ldD = new JLabel();
	JTextField tbOffering = new JTextField();
	
	JButton butSubmit = new JButton();
	JButton butCancel = new JButton();

	JLabel tradeLabel = new JLabel();
	JLabel dDLabel = new JLabel();
	JLabel offerLabel = new JLabel();
	JLabel oneofferLabel = new JLabel();
	JLabel selectedLabel = new JLabel();

	SellerTradingMenu() {
		try {
			dispbx();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void dispbx() throws Exception {

		tradeLabel.setText("Trade : ");
		tradeLabel.setBounds(new Rectangle(20, 36, 91, 18));
		this.getContentPane().setLayout(null);
		
		lTradingName.setText("jtname");
		lTradingName.setBounds(new Rectangle(258, 35, 282, 18));
		
		dDLabel.setText("Bid Date");
		dDLabel.setBounds(new Rectangle(21, 81, 92, 18));
		
		ldD.setText("jtdD");
		ldD.setBounds(new Rectangle(254, 82, 294, 18));
		
		offerLabel.setText("Min Offer");
		offerLabel.setBounds(new Rectangle(24, 128, 93, 18));
		
		tbOffering.setText("jtoffer");
		tbOffering.setBounds(new Rectangle(251, 127, 211, 22));
		
		butSubmit.setText("Submit");
		butSubmit.setBounds(new Rectangle(476, 124, 79, 29));
		
		
		
		butSubmit.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(ActionEvent t) {
				bSubmitActionPerformed(t);
			}
		});
		butCancel.setText("Cancel");
		butCancel.setBounds(new Rectangle(475, 164, 79, 29));
		butCancel.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bCancelActionPerformed(e);
			}
		});
		this.getContentPane().add(tradeLabel, null);
		this.getContentPane().add(lTradingName, null); // insert name of item
		this.getContentPane().add(dDLabel, null);
		this.getContentPane().add(ldD, null); //insert due date
		this.getContentPane().add(offerLabel, null);
		this.getContentPane().add(tbOffering, null);// insert minimum offer
		this.getContentPane().add(butSubmit, null);
		this.getContentPane().add(butCancel, null);
	}
	
	void bCancelActionPerformed(ActionEvent t) {
		boolSubmit = false;
		setVisible(false);
	}

	/*
	 * check for an offer by buyer, select the biggest offer if exists.
	 */
	public void ShowMenu(Trading trade, Person person) {
		strade = trade;
		
	}

		
	void bSubmitActionPerformed(ActionEvent t) {
		boolSubmit = true;
		setVisible(false);
	}

	
	

}