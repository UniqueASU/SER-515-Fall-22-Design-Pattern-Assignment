package PTBS;

//This class is derived from ProductMenu and  implements Bridge design pattern.
public class MeatProductMenu extends ProductMenu {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void ShowMenu(Product product) {

	}

	public void showAddButton() {

	}

	public void showViewButton() {

	}

	public void showRadioButton() {

	}

	public void showLabels() {

	}

	public void showComboxes() {

	}

	@Override
	public void showMenu(Product product) {
		// TODO Auto-generated method stub
		
	}

}
